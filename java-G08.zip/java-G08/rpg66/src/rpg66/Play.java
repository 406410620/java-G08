package rpg66;

public class Play {

	public static void main(String[] args) throws InterruptedException  {
		MyFrame frame = new MyFrame("sixsix"); 
		frame.setSize(1400, 800);
		frame.setExtendedState(frame.MAXIMIZED_BOTH);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setResizable(true);
		frame.setVisible(true);
		frame.gamestart();
		
	}

}
